package reporting;

import java.util.*;

public class Reporting {
    public void generateReports(HashMap<String, Integer> stockCount) {
        System.out.println("\nGenerating reports...");
        
        // Inventory Report
        System.out.println("Inventory Report:");
        int totalItems = stockCount.size();
        int overstocked = 0;
        int understocked = 0;
        
        for (String item : stockCount.keySet()) {
            int stock = stockCount.get(item);
            if (stock > 50) { // Example threshold for overstocked
                overstocked++;
            } else if (stock < 10) { // Example threshold for understocked
                understocked++;
            }
        }

        System.out.println("- Total Items: " + totalItems);
        System.out.println("- Overstocked Items: " + overstocked);
        System.out.println("- Understocked Items: " + understocked);

        // User Activity Report (kept static for now)
        System.out.println("\nUser Activity Report:");
        System.out.println("- Total Logins Today: 10");
        System.out.println("- Actions Taken: 45");
    }
}
