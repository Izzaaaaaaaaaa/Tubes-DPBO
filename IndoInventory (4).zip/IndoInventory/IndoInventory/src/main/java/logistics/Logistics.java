package logistics;

import java.util.*;

public class Logistics {
    private ArrayList<String> schedules = new ArrayList<>();

    public Logistics() {
        schedules.add("Delivery to Kendal at 10 AM");
        schedules.add("Delivery to Medan at 2 PM");
    }

    public void manageLogistics() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nLogistics Menu:");
            System.out.println("1. View Delivery Schedules");
            System.out.println("2. Add Delivery Schedule");
            System.out.println("3. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    viewSchedules();
                    break;
                case 2:
                    addSchedule();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private void viewSchedules() {
        System.out.println("\nCurrent Delivery Schedules:");
        for (String schedule : schedules) {
            System.out.println("- " + schedule);
        }
    }

    private void addSchedule() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter new delivery schedule: ");
        String schedule = scanner.nextLine();

        schedules.add(schedule);
        System.out.println("Delivery schedule added successfully!");
    }

    public void manageLogistics(String admin) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}