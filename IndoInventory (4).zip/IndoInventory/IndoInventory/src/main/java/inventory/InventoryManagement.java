package inventory;

import java.util.*;

public class InventoryManagement {
    private static class Product {
        String name;
        String code;
        String category;
        double price;
        int stock;
        Date expiryDate;

        Product(String name, String code, String category, double price, int stock, Date expiryDate) {
            this.name = name;
            this.code = code;
            this.category = category;
            this.price = price;
            this.stock = stock;
            this.expiryDate = expiryDate;
        }
    }

    private ArrayList<Product> inventoryList = new ArrayList<>();
    private HashMap<String, Product> productMap = new HashMap<>();

    public InventoryManagement() {
        // Initial Inventory Setup
        addProduct("Indomie Goreng 80g", "123456", "Makanan", 3000, 50, getDate("2025-02-01"));
        addProduct("Aqua Botol 600ml", "789012", "Minuman", 5000, 30, getDate("2025-12-31"));
    }

    public void manageInventory(String role) {
        if (!"Admin".equals(role)) {
            System.out.println("Access denied. Only admins can manage inventory.");
            return;
        }

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nInventory Menu:");
            System.out.println("1. View Inventory");
            System.out.println("2. Add Product");
            System.out.println("3. Update Stock");
            System.out.println("4. View Expired Products");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear buffer

            switch (choice) {
                case 1:
                    viewInventory();
                    break;
                case 2:
                    addProductInteractive(scanner);
                    break;
                case 3:
                    updateStock(scanner);
                    break;
                case 4:
                    viewExpiredProducts();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private void viewInventory() {
        System.out.println("\nCurrent Inventory:");
        for (Product product : inventoryList) {
            System.out.printf("Name: %s, Code: %s, Category: %s, Price: %.2f, Stock: %d, Expiry Date: %s\n",
                product.name, product.code, product.category, product.price, product.stock,
                product.expiryDate != null ? product.expiryDate.toString() : "N/A");
        }
    }

    private void addProductInteractive(Scanner scanner) {
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter product code/barcode: ");
        String code = scanner.nextLine();
        System.out.print("Enter category: ");
        String category = scanner.nextLine();
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();
        System.out.print("Enter stock: ");
        int stock = scanner.nextInt();
        scanner.nextLine(); // Clear buffer
        System.out.print("Enter expiry date (yyyy-mm-dd) or press enter if not applicable: ");
        String expiryInput = scanner.nextLine();
        Date expiryDate = null;
        if (!expiryInput.isEmpty()) {
            try {
                expiryDate = new java.text.SimpleDateFormat("yyyy-MM-dd").parse(expiryInput);
            } catch (Exception e) {
                System.out.println("Invalid date format. Skipping expiry date.");
            }
        }

        addProduct(name, code, category, price, stock, expiryDate);
        System.out.println("Product added successfully!");
    }

    private void addProduct(String name, String code, String category, double price, int stock, Date expiryDate) {
        Product product = new Product(name, code, category, price, stock, expiryDate);
        inventoryList.add(product);
        productMap.put(code, product);
    }

    private void updateStock(Scanner scanner) {
        System.out.print("Enter product code: ");
        String code = scanner.nextLine();

        if (productMap.containsKey(code)) {
            Product product = productMap.get(code);
            System.out.print("Enter new stock value: ");
            int newStock = scanner.nextInt();
            product.stock = newStock;
            System.out.println("Stock updated successfully!");
        } else {
            System.out.println("Product not found.");
        }
    }

    private void viewExpiredProducts() {
        System.out.println("\nExpired Products:");
        Date today = new Date();
        boolean found = false;
        for (Product product : inventoryList) {
            if (product.expiryDate != null && product.expiryDate.before(today)) {
                System.out.printf("Name: %s, Code: %s, Expired on: %s\n",
                    product.name, product.code, product.expiryDate);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No expired products.");
        }
    }

    private Date getDate(String dateStr) {
        try {
            return new java.text.SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
        } catch (Exception e) {
            return null;
        }
    }

    public HashMap<String, Integer> getStockCount() {
        HashMap<String, Integer> stockCount = new HashMap<>();
        for (Product product : inventoryList) {
            stockCount.put(product.name, product.stock);
        }
        return stockCount;
    }
}
