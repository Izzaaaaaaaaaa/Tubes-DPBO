package main;

import inventory.InventoryManagement;
import reporting.Reporting;
import logistics.Logistics;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Login System
        System.out.println("Welcome ADMIN");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        // Hardcoded credentials for simplicity
        if (!username.equals("admin") || !password.equals("password123")) {
            System.out.println("Invalid credentials. Exiting system.");
            return;
        }

        System.out.println("\nWelcome to IndoInventory Management System!");

        // Initialize Modules
        InventoryManagement inventory = new InventoryManagement();
        Reporting reporting = new Reporting();
        Logistics logistics = new Logistics();

        // Main Menu
        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Manage Inventory");
            System.out.println("2. View Reports");
            System.out.println("3. Manage Logistics");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Clear input buffer

            switch (choice) {
                case 1:
                    inventory.manageInventory("Admin");
                    break;
                case 2:
                    reporting.generateReports(inventory.getStockCount());
                    break;
                case 3:
                    logistics.manageLogistics("Admin");
                    break;
                case 4:
                    System.out.println("======Thank you for using IndoInventory. Goodbye!======");
                    return; // Exit the program
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
